import random
import json
import pandas as pd
import os
import google.generativeai as genai
from PIL import Image
import base64
from io import BytesIO

API_keys = [
    'AIzaSyBJtqJ2Sz7bDjgJGDl0vNsstpoXyI7W0Ic',
    'AIzaSyBQHkKbr5-6gaGGr5JnXDt0C14Yr3WF-OQ'
]

def remove_keys(ontology_dict, r_keys):
    if type(ontology_dict) != dict:
        return ontology_dict
    keys = ontology_dict.keys()
    res_dict = {}
    for key in keys:
        if key in r_keys:
            continue
        res_dict[key] = remove_keys(ontology_dict[key], r_keys)
    return res_dict

def filter_by(site=None, modality=None, ontology_dict={}):
    keys = ontology_dict.keys()
    # print(keys)
    res_dict = {}
    good = True
    for key in keys:
        if key == 'child':
            incoming_dict = filter_by(site, modality, ontology_dict[key])
            if incoming_dict:
                res_dict[key] = incoming_dict
        elif key == 'site':
            if site is None or site in ontology_dict[key]:
                res_dict[key] = ontology_dict[key]
            else:
                good = False
        elif key == 'modalities':
            if modality is None or modality in ontology_dict[key]:
                res_dict[key] = ontology_dict[key]
            else:
                good = False
        else:
            incoming_dict = filter_by(site, modality, ontology_dict[key])
            if incoming_dict:
                res_dict[key] = incoming_dict
    if good:
        return res_dict
    return {}

def get_unique_sites(ontology_dict={}):
    keys = ontology_dict.keys()
    sites = set()
    for key in keys:
        if key == 'site':
            sites = set(ontology_dict[key]).union(sites)
        elif key == 'modalities':
            continue
        else:
            sites = set(get_unique_sites(ontology_dict[key])).union(sites)
    return sites

def get_unique_modalities(ontology_dict={}):
    keys = ontology_dict.keys()
    modalities = set()
    for key in keys:
        if key == 'site':
            continue
        elif key == 'modalities':
            modalities = set(ontology_dict[key]).union(modalities)
        else:
            modalities = set(get_unique_modalities(ontology_dict[key])).union(modalities)
    return modalities

def serialize_ontology(ontology_dict={}):
    def serialize(cur_str, res_list, ontology_dict):
        if cur_str != "":
            res_list.append(cur_str)
        if ontology_dict == {}:
            return
        keys = ontology_dict.keys()
        for key in keys:
            if key == 'child':
                serialize(cur_str, res_list, ontology_dict[key])
            else:
                if cur_str == "":
                    serialize(key, res_list, ontology_dict[key])
                else:
                    serialize(cur_str + ", " + key, res_list, ontology_dict[key])

    res_list, cur_str = [], ""
    serialize(cur_str, res_list, ontology_dict)
    return list(set(res_list))

def do_site_search(unique_sites, base64_image):
    site_question_template = "Which site does the following medical image belong to? Only print the option you choose."
    possible_sites = list(unique_sites)
    generation_config = {
        "temperature": 0,
        "top_p": 0.95,
        "top_k": 40,
        "max_output_tokens": 8192,
        "response_mime_type": "text/plain",
    }
    logs = []
    while len(possible_sites) > 1:
        if len(possible_sites) < 4:
            for site in unique_sites:
                if site not in possible_sites:
                    possible_sites.append(site)
                if len(possible_sites) == 4:
                    break
        random.shuffle(possible_sites)
        question = f'{site_question_template}\nA) {possible_sites[0]}\nB) {possible_sites[1]}\nC) {possible_sites[2]}\nD) {possible_sites[3]}\nAnswer: '
        model = genai.GenerativeModel(
            model_name="gemini-1.5-flash-8b",
            generation_config=generation_config,
        )
        response = model.generate_content([{'mime_type':'image/jpeg', 'data': base64_image}, question])
        for i, option in enumerate(['A', 'B', 'C', 'D']):
            if option == response.text[0]:
                keep = i
                break
        assert keep is not None
        logs.append(f'Given {possible_sites[:4]}, {possible_sites[keep]} is chosen. The model response is {response.text}.')
        possible_sites = possible_sites[4:] + [possible_sites[keep]]
    return possible_sites[0], logs

def do_modality_search(unique_modalities, base64_image):
    modality_question_template = "Which modality does the following medical image belong to? Only print the option you choose."
    possible_modalities = list(unique_modalities)
    generation_config = {
        "temperature": 0,
        "top_p": 0.95,
        "top_k": 40,
        "max_output_tokens": 8192,
        "response_mime_type": "text/plain",
    }
    logs = []
    while len(possible_modalities) > 1:
        if len(possible_modalities) < 4:
            for modality in unique_modalities:
                if modality not in possible_modalities:
                    possible_modalities.append(modality)
                if len(possible_modalities) == 4:
                    break
        random.shuffle(possible_modalities)
        model = genai.GenerativeModel(
            model_name="gemini-1.5-flash-8b",
            generation_config=generation_config,
        )
        question = f'{modality_question_template}\nA) {possible_modalities[0]}\nB) {possible_modalities[1]}\nC) {possible_modalities[2]}\nD) {possible_modalities[3]}\nAnswer: '
        response = model.generate_content([{'mime_type':'image/jpeg', 'data': base64_image}, question])
        for i, option in enumerate(['A', 'B', 'C', 'D']):
            if option == response.text[0]:
                keep = i
                break
        assert keep is not None
        logs.append(f'Given {possible_modalities[:4]}, {possible_modalities[keep]} is chosen. The model response is {response.text}.')
        possible_modalities = possible_modalities[4:] + [possible_modalities[keep]]
    return possible_modalities[0], logs

def do_object_type_search(modality, site, unique_object_types, base64_image, prompt_type):
    example_question_template_0 = "Given the following medical image from the {} modality and in the {} site, can we confidently deduce the following from this image ({})? Only print the option you choose.\nA) Yes\nB) No\nAnswer: "
    example_question_template_1 = "Given the following medical image from the {} modality and in the {} site, can we confidently observe the following {} in this image: {}? Only print the option you choose.\nA) Yes\nB) No\nAnswer: "
    example_question_template_2 = "Given the following medical image from the {} modality and in the {} site, can we confidently observe the following {} in this image: {}? Only print the option you choose.\nA) Yes\nB) No\nAnswer: "
    generation_config = {
        "temperature": 0,
        "top_p": 0.95,
        "top_k": 40,
        "max_output_tokens": 8192,
        "response_mime_type": "text/plain",
    }
    existing = []
    logs = []
    for item in unique_object_types:
        # i0, i1, i2 = (x.strip() for x in item.split(','))
        # if prompt_type == 0:
        question = example_question_template_0.format(modality, site, item)
        # elif prompt_type == 1:
        #     question = example_question_template_1.format(modality, site, i0, i2)
        # elif prompt_type == 2:
        #     question = example_question_template_2.format(modality, site, i1, i2)
        model = genai.GenerativeModel(
            model_name="gemini-1.5-flash",
            generation_config=generation_config,
        )
        response = model.generate_content([{'mime_type':'image/jpeg', 'data': base64_image}, question])
        if response.text[0] == 'A':
            keep = True
        elif response.text[0] == 'B':
            keep = False
        else:
            keep = None
        logs.append(f'Given the {modality} modality, {site} site and {item}, the model response is {response.text}.')
        if keep == True:
            existing.append(item)
    return existing, logs

# def do_object_type_search(modality, site, unique_object_types, base64_image, prompt_type):
#     example_question_templates = [
#         "Given the following medical image from the {} modality and in the {} site, can we confidently deduce the following from this image ({})? Only print the option you choose.\nA) Yes\nB) No\nAnswer: ",
#         "Given the following medical image from the {} modality and in the {} site, can we confidently observe the following {} in this image: {}? Only print the option you choose.\nA) Yes\nB) No\nAnswer: ",
#         "Given the following medical image from the {} modality and in the {} site, can we confidently observe the following {} in this image: {}? Only print the option you choose.\nA) Yes\nB) No\nAnswer: "
#     ]

#     generation_config = {
#         "temperature": 0,
#         "top_p": 0.95,
#         "top_k": 40,
#         "max_output_tokens": 8192,
#         "response_mime_type": "text/plain",
#     }
    
#     # Prepare batch prompts
#     batch_requests = []
#     for item in unique_object_types:
#         # i0, i1, i2 = (x.strip() for x in item.split(','))
#         # if prompt_type == 0:
#         question = example_question_templates[0].format(modality, site, item)
#         # elif prompt_type == 1:
#         #     question = example_question_templates[1].format(modality, site, i0, i2)
#         # elif prompt_type == 2:
#         #     question = example_question_templates[2].format(modality, site, i1, i2)
#         # else:
#         #     raise ValueError("Invalid prompt_type")

#         # Append to batch requests
#         batch_requests.append({
#             'inputs': [
#                 {'mime_type': 'image/jpeg', 'data': base64_image},
#                 question
#             ]
#         })

#     # Instantiate the model once
#     model = genai.GenerativeModel(
#         model_name="gemini-1.5-flash",
#         generation_config=generation_config,
#     )
    
#     # Batch inference
#     responses = model.generate_content(batch_requests)

#     # Process responses
#     existing = []
#     logs = []
#     for item, response in zip(unique_object_types, responses):
#         if response.text[0] == 'A':
#             keep = True
#         elif response.text[0] == 'B':
#             keep = False
#         else:
#             keep = None
        
#         logs.append(f'Given the {modality} modality, {site} site and {item}, the model response is {response.text}.')
#         if keep:
#             existing.append(item)

#     return existing, logs

def describe_image(image_file_path, csv_append_path, prompt_type):
    ontology_file = '/content/drive/Shareddrives/CS286-project/VLM-Segmentation-Project/BiomedParseFiles/hierarchy.json'
    # load
    with open(ontology_file) as f:
        ontology = json.load(f)
    ontology = remove_keys(ontology, ['name'])

    unique_sites = unique_sites = get_unique_sites(ontology)
    unique_modalities = get_unique_modalities(ontology)

    # genai.configure(api_key=API_keys[random.randint(0, len(API_keys)-1)])
    genai.configure(api_key=API_keys[1])

    # Open the image with Pillow
    with Image.open(image_file_path) as img:
        # Save the image to a BytesIO buffer in JPEG format
        buffer = BytesIO()
        img.save(buffer, format="png")
        buffer.seek(0)
        
        # Convert buffer to base64 string
        base64_image = base64.b64encode(buffer.read()).decode('utf-8')

    site, site_logs = do_site_search(unique_sites, base64_image)
    print("site search done")
    modality, modality_logs = do_modality_search(unique_modalities, base64_image)
    print("modality search done")
    new_ont = filter_by(site, modality, ontology)
    new_ont = remove_keys(new_ont, ['site', 'modalities'])
    serialization = serialize_ontology(new_ont)

    object_types, object_type_logs = do_object_type_search(modality, site, serialization, base64_image, prompt_type)
    print("object type search done")
    # append to csv
    # csv has the columns: image_path, site, modality, object_types, site_logs, modality_logs, object_type_logs
    df = pd.DataFrame([[image_file_path, site, modality, object_types, site_logs, modality_logs, object_type_logs]], columns=['image_path', 'site', 'modality', 'object_types', 'site_logs', 'modality_logs', 'object_type_logs'])
    if os.path.exists(csv_append_path):
        df.to_csv(csv_append_path, mode='a', header=False, index=False)
    else:
        df.to_csv(csv_append_path, mode='w', header=True, index=False)

    return site, modality, object_types, site_logs, modality_logs, object_type_logs